import styled from 'styled-components';

const PageView = styled.main`
  display: flex;
`;

export default PageView;
