import styled from 'styled-components';

export default function GameCard ({ game, rentInfo }) {
  return (
    <div>lalala</div>
  );
}
